function check() {
    var i7 = document.getElementById('i7');
    var a7 = document.getElementById('a7');
    if (i7.value === "7") {
        a7.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a7.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i6 = document.getElementById('i6');
    var a6 = document.getElementById('a6');
    if (i6.value === "6") {
        a6.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a6.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i26 = document.getElementById('i26');
    var a26 = document.getElementById('a26');
    if (i26.value === "26") {
        a26.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a26.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i15 = document.getElementById('i15');
    var a15 = document.getElementById('a15');
    if (i15.value === "15") {
        a15.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a15.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var ii6 = document.getElementById('ii6');
    var aa6 = document.getElementById('aa6');
    if (ii6.value === "6") {
        aa6.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        aa6.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i73 = document.getElementById('i73');
    var a73 = document.getElementById('a73');
    if (i73.value === "73") {
        a73.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a73.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i5 = document.getElementById('i5');
    var a5 = document.getElementById('a5');
    if (i5.value === "5") {
        a5.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a5.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i16 = document.getElementById('i16');
    var a16 = document.getElementById('a16');
    if (i16.value === "16") {
        a16.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a16.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i45 = document.getElementById('i45');
    var a45 = document.getElementById('a45');
    if (i45.value === "45") {
        a45.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a45.style.background = "rgba(228, 5, 5, 0.386)";
    }


    var i12 = document.getElementById('i12');
    var a12 = document.getElementById('a12');
    if (i12.value === "12") {
        a12.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a12.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i29 = document.getElementById('i29');
    var a29 = document.getElementById('a29');
    if (i29.value === "29") {
        a29.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a29.style.background = "rgba(228, 5, 5, 0.386)";
    }

    var i8 = document.getElementById('i8');
    var a8 = document.getElementById('a8');
    if (i8.value === "8") {
        a8.style.background = "rgba(69, 185, 69, 0.533)";
    }
    else {
        a8.style.background = "rgba(228, 5, 5, 0.386)";
    }
}